# Delícias Gourmet - Confeitaria Artesanal

Site completo, moderno e responsivo para a confeitaria **Delícias Gourmet** (Tamoios, Cabo Frio - RJ).

## 🚀 Como publicar na Vercel

1. **Baixe este projeto** e descompacte os arquivos.
2. **Suba para o GitHub**:
   - Crie um novo repositório no seu GitHub (ex: `delicias-gourmet-site`).
   - Faça o upload do arquivo `index.html` e `README.md` no repositório.
3. **Conecte à Vercel**:
   - Acesse [Vercel](https://vercel.com) e faça login.
   - Clique em **"Add New..."** -> **"Project"**.
   - Selecione o repositório do GitHub `delicias-gourmet-site`.
   - Clique em **"Deploy"**.

Pronto! Seu site estará no ar em menos de 1 minuto com link HTTPS seguro!
